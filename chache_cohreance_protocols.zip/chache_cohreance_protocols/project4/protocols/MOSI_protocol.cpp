#include "MOSI_protocol.h"
#include "../sim/mreq.h"
#include "../sim/sim.h"
#include "../sim/hash_table.h"

extern Simulator *Sim;

/*************************
 * Constructor/Destructor.
 *************************/
MOSI_protocol::MOSI_protocol (Hash_table *my_table, Hash_entry *my_entry)
    : Protocol (my_table, my_entry)
{
    this->state = MOSI_CACHE_I;
}

MOSI_protocol::~MOSI_protocol ()
{    
}

void MOSI_protocol::dump (void)
{
    const char *block_states[5] = {"X","I","S","O","M"};
    fprintf (stderr, "MOSI_protocol - state: %s\n", block_states[state]);
}

void MOSI_protocol::process_cache_request (Mreq *request)
{
	switch (state) {
        case MOSI_CACHE_I:  do_cache_I (request); break;
        case MOSI_CACHE_S:  do_cache_S (request); break;
        case MOSI_CACHE_O:  do_cache_O (request); break;
        case MOSI_CACHE_M:  do_cache_M (request); break;
        case MOSI_CACHE_IS: do_cache_IS (request); break;
        case MOSI_CACHE_IM: do_cache_IM (request); break;
        case MOSI_CACHE_OM: do_cache_OM (request); break;
        case MOSI_CACHE_SM:  do_cache_SM (request); break;
        default:
            fatal_error ("Invalid Cache State for MOSI Protocol\n");
    }
}

void MOSI_protocol::process_snoop_request (Mreq *request)
{
	switch (state) {
        case MOSI_CACHE_I:  do_snoop_I (request); break;
        case MOSI_CACHE_S:  do_snoop_S (request); break;
        case MOSI_CACHE_O:  do_snoop_O (request); break;
        case MOSI_CACHE_M:  do_snoop_M (request); break;
        case MOSI_CACHE_IS: do_snoop_IS (request); break;
        case MOSI_CACHE_IM: do_snoop_IM (request); break;
        case MOSI_CACHE_OM: do_snoop_OM (request); break;
        case MOSI_CACHE_SM:  do_snoop_SM (request); break;
        default:
            fatal_error ("Invalid Cache State for MOSI Protocol\n");
    }
}
/*
 * invalidate: meaning the block is not available currently
 * state if we get read we go to the S state (IS just for transion )
 * and if it a load go to the modified state M (IM for transion )
 */
inline void MOSI_protocol::do_cache_I (Mreq *request)
{
    switch (request->msg) {
        case LOAD:
            send_GETS(request->addr);
            state = MOSI_CACHE_IS;
            Sim->cache_misses++;
            break;
        case STORE:
            send_GETM(request->addr);
            state = MOSI_CACHE_IM;
            Sim->cache_misses++;
            break;
        default:
            request->print_msg (my_table->moduleID, "ERROR");
            fatal_error ("Client: I state shouldn't see this message\n");
    }
}
/*
 * transion state betwenn I And S
 * If the block is in the IS state that means it sent out a GET message
 * and is waiting on DATA.  Therefore the processor should be waiting
 * on a pending request. Therefore we should not be getting any requests from
 * the processor.
 */
inline void MOSI_protocol::do_cache_IS (Mreq *request)
{
    switch (request->msg) {

        case LOAD:
        case STORE:
            request->print_msg (my_table->moduleID, "ERROR");
            fatal_error("Should only have one outstanding request per processor!");
        default:
            request->print_msg (my_table->moduleID, "ERROR");
            fatal_error ("Client: I state shouldn't see this message\n");
    }
}
/* transition state between I and M
 * If the block is in the IM state that means it sent out a GET message
 * and is waiting on DATA.  Therefore the processor should be waiting
 * on a pending request. Therefore we should not be getting any requests from
 * the processor.
 */
inline void MOSI_protocol::do_cache_IM (Mreq *request)
{
    switch (request->msg) {
        case LOAD:
        case STORE:
            request->print_msg (my_table->moduleID, "ERROR");
            fatal_error("Should only have one outstanding request per processor!");
        default:
            request->print_msg (my_table->moduleID, "ERROR");
            fatal_error ("Client: I state shouldn't see this message\n");
    }
}
/*
 * shared state: This block is unmodified and exists in read-only state in at least one cache. and we can evict data without a writeback
 * if we get load we just provide the data to the processo
 * if we get store we set it to invalidate and the send to the modified state to modify it.
 */
inline void MOSI_protocol::do_cache_S (Mreq *request)
{
    switch (request->msg) {
        case LOAD:

            send_DATA_to_proc(request->addr);
            break;
        case STORE:

            send_GETM(request->addr);
            state = MOSI_CACHE_SM;
            Sim->cache_misses++;
            break;
        default:
            request->print_msg (my_table->moduleID, "ERROR");
            fatal_error ("Client: M state shouldn't see this message\n");
    }
}
inline void MOSI_protocol::do_cache_SM (Mreq *request)
{
    switch (request->msg) {
        case LOAD:
        case STORE:
            request->print_msg (my_table->moduleID, "ERROR");
            fatal_error("Should only have one outstanding request per processor!");
        default:
            request->print_msg (my_table->moduleID, "ERROR");
            fatal_error ("Client: I state shouldn't see this message\n");
    }
}
/*
 * owend state: Multiple caches may hold the most recent and correct value of a block and the value in main memory may or may not be correct. At a time, only one cache can have the owned state for a block. All the other caches with the same block must be in shared state.
 *  if we get load we send data to the prossesor since it a clean data
 *  if we get store then its a we go the modified state (om while transitioning)
 */
inline void MOSI_protocol::do_cache_O (Mreq *request)
{
    switch (request->msg) {

        case LOAD:
            send_DATA_to_proc(request->addr);
            break;
        case STORE:
            send_GETM(request->addr);
            state = MOSI_CACHE_OM;
            Sim->cache_misses++;                                                                          // Think over it
            break;
        default:
            request->print_msg (my_table->moduleID, "ERROR");
            fatal_error ("Client: M state shouldn't see this message\n");
    }
}
/* transition state between O and M
 * If the block is in the OM state that means it sent out a GET message
 * and is waiting on DATA.  Therefore the processor should be waiting
 * on a pending request. Therefore we should not be getting any requests from
 * the processor.
 */
inline void MOSI_protocol::do_cache_OM (Mreq *request)
{
    switch (request->msg) {
        case LOAD:
        case STORE:
            request->print_msg (my_table->moduleID, "ERROR");
            fatal_error("Should only have one outstanding request per processor!");
        default:
            request->print_msg (my_table->moduleID, "ERROR");
            fatal_error ("Client: I state shouldn't see this message\n");
    }
}
/*
 * modified state: we modify data in this state and write back it to memory inorder to make sure memory have the correct data
 * The M state means we have the data and we can modify it.
 * Therefore any requestfrom the processor (read or write) can be immediately satisfied.
 */
inline void MOSI_protocol::do_cache_M (Mreq *request)
{
    switch (request->msg) {
        case LOAD:
        case STORE:
            /* This is how you send data back to the processor to finish the request
             * Note: There was no need to send anything on the bus on a hit.
             */
            send_DATA_to_proc(request->addr);
            break;
        default:
            request->print_msg (my_table->moduleID, "ERROR");
            fatal_error ("Client: M state shouldn't see this message\n");
    }
}


/*
 * I state for the bus
 * If we snoop a message from another cache and we are in I, then we don't
 * need to do anything!  We obviously cannot supply data since we don't have
 * it, and we don't need to downgrade our state since we are already in I.
 */
inline void MOSI_protocol::do_snoop_I (Mreq *request)
{
    switch (request->msg) {
        case GETS:
        case GETM:
        case DATA:
            break;
        default:
            request->print_msg (my_table->moduleID, "ERROR");
            fatal_error ("Client: I state shouldn't see this message\n");
    }
}
/*
 * transition state
 * going S form I
 * since we are waitng on data dont do any thing on the other requests,
 * once we got data send it to the processor but id the block is not shared go to E state insted of S stae
 */
inline void MOSI_protocol::do_snoop_IS (Mreq *request)
{
    switch (request->msg) {
        case GETS:
        case GETM:
            break;
        case DATA:

            send_DATA_to_proc(request->addr);
            state = MOSI_CACHE_S;
            break;
        default:
            request->print_msg (my_table->moduleID, "ERROR");
            fatal_error ("Client: I state shouldn't see this message\n");
    }
}
/*
 * trasnsrtion state
 * going M to I
 * since we are waiting on data we dont nee to do anything on request
 * once we got the data send it to the processot and move to M state
 */
inline void MOSI_protocol::do_snoop_IM (Mreq *request)
{
    switch (request->msg) {
        case GETS:
        case GETM:
            break;
        case DATA:
            send_DATA_to_proc(request->addr);
            state = MOSI_CACHE_M;
            break;
        default:
            request->print_msg (my_table->moduleID, "ERROR");
            fatal_error ("Client: I state shouldn't see this message\n");
    }
}
/*
 * s state for snoop bus
 * if we are in shared state and someone is asking to share data than stay in ths same state
 * if someone ask to modify the data invalidate the copy since it wiil be stale and move to I state
 */
inline void MOSI_protocol::do_snoop_S (Mreq *request)
{
    switch (request->msg) {
        case GETS:
            /*
             * if we see gets request on bus, sise we have the data we just share ans stay in the same state
             */
            set_shared_line();
            break;
        case GETM:
            /*
             * if its getM then invalidate the cashes and go to the I state
             */
            set_shared_line();
            state = MOSI_CACHE_I;
            break;
        case DATA:
            fatal_error ("Should not see data for this line!  I have the line!");
            break;
        default:
            request->print_msg (my_table->moduleID, "ERROR");
            fatal_error ("Client: M state shouldn't see this message\n");
    }
}
/*
 * trasnsrtion state
 * going M from S
 * Ignore, wait for data when we gets share it on bus
 * But for getM also share it on bus and send it to IM to invalidate the other copies
 * if we got the data than send it to the processor and move to state M
 */
inline void MOSI_protocol::do_snoop_SM (Mreq *request)
{
    switch (request->msg) {
        case GETS:
        case GETM:
            break;
        case DATA:
            send_DATA_to_proc(request->addr);
            state = MOSI_CACHE_M;
            break;
        default:
            request->print_msg (my_table->moduleID, "ERROR");
            fatal_error ("Client: I state shouldn't see this message\n");
    }
}
/*
 * O state for bus
 * On a Gets, the cache block is sent on bus and we stay in the same state
 * on a GetM, the cache block is sent on bus and state changes to invalid
 */
inline void MOSI_protocol::do_snoop_O (Mreq *request)
{
    switch (request->msg) {
        case GETS:
            set_shared_line();
            send_DATA_on_bus(request->addr,request->src_mid);
            break;
        case GETM:
            set_shared_line();
            send_DATA_on_bus(request->addr,request->src_mid);
            state = MOSI_CACHE_I;
            break;
        case DATA:
            fatal_error ("Should not see data for this line!  I have the line!");
            break;
        default:
            request->print_msg (my_table->moduleID, "ERROR");
            fatal_error ("Client: M state shouldn't see this message\n");
    }
}
/*
 * trasnsrtion state
 * going M from O
 * Ignore, wait for data when we gets share it on bus
 * But for getM also share it on bus and send it to IM to invalidate the other copies
 * if we got the data than send it to the processor and move to state M
 */
inline void MOSI_protocol::do_snoop_OM (Mreq *request)
{
    switch (request->msg) {
        case GETS:
            set_shared_line();
            send_DATA_on_bus(request->addr,request->src_mid);
            break;
        case GETM:
            /* The processor is transitioning from O state to M state
             * So if it sees GETM, it has to go to the IM state
             */
            set_shared_line();
            send_DATA_on_bus(request->addr,request->src_mid);
            state = MOSI_CACHE_IM;
            break;
        case DATA:
            send_DATA_to_proc(request->addr);
            state = MOSI_CACHE_M;
            break;
        default:
            request->print_msg (my_table->moduleID, "ERROR");
            fatal_error ("Client: I state shouldn't see this message\n");
    }
}
/*
 * M state for bus
 * On a Gets, the cache block is sent on bus and state changes to owned (casue it has the only fresh copy)
 * on a GetM, the cache block is sent on bus and state changes to invalid
 */
inline void MOSI_protocol::do_snoop_M (Mreq *request)
{
    switch (request->msg) {
        case GETS:
            set_shared_line();
            send_DATA_on_bus(request->addr,request->src_mid);
            state = MOSI_CACHE_O;
            break;
        case GETM:
            set_shared_line();
            send_DATA_on_bus(request->addr,request->src_mid);
            state = MOSI_CACHE_I;
            break;
        case DATA:
            fatal_error ("Should not see data for this line!  I have the line!");
            break;
        default:
            request->print_msg (my_table->moduleID, "ERROR");
            fatal_error ("Client: M state shouldn't see this message\n");
    }
}


